import Vue from 'vue'
import VNepaliDatePicker from 'v-nepalidatepicker';

Vue.use(VNepaliDatePicker)
