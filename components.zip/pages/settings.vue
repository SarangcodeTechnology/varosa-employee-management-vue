<template>
            <h1>This is Settings page</h1>
</template>

<script>
export default {
  name: "settings"
}
</script>

<style scoped>

</style>
