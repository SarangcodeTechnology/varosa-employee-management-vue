<template>
            <h1>This is Change Password page</h1>
</template>

<script>
export default {
  name: "ChangePassword"
}
</script>

<style scoped>

</style>
