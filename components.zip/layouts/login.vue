<template>
  <v-app>
    <v-main>
      <v-container fluid>
        <Nuxt/>
      </v-container>
    </v-main>
  </v-app>
</template>

<script>

export default {
  name: "login",
}
</script>

<style scoped>

</style>
