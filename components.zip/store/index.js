export const strict = false
